// VENTANA DE DETALLE (código): muestra un préstamo y permite registrar su devolución.
using System.IO;
using System.Windows;
using PrestamosGC.Datos;

namespace PrestamosGC;

public partial class VentanaDetalle : Window
{
    // El préstamo llega por el constructor.
    public VentanaDetalle(Prestamo prestamo)
    {
        InitializeComponent();

        // DataContext: "de dónde sacan los datos los Binding del XAML".
        // Al poner aquí el préstamo, {Binding Correo} busca prestamo.Correo.
        DataContext = prestamo;
    }

    // Botón "Registrar devolución".
    private void Devolucion_Click(object sender, RoutedEventArgs e)
    {
        // DataContext es de tipo object: lo convertimos a Prestamo con (Prestamo).
        Prestamo prestamo = (Prestamo)DataContext;

        // Pedimos confirmación con Sí / No.
        MessageBoxResult respuesta = MessageBox.Show(
            this,
            "¿Registrar la devolución del portátil " + prestamo.Portatil + " de " + prestamo.NombreCompleto + "?",
            "Confirmar devolución",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        // Si no ha pulsado Sí, no hacemos nada.
        if (respuesta != MessageBoxResult.Yes) return;

        try
        {
            App.Prestamos.RegistrarDevolucion(prestamo.Id);
        }
        // "when": este catch captura solo esos tres tipos de error, y los tres se tratan igual.
        catch (Exception ex) when (ex is InvalidOperationException or IOException or UnauthorizedAccessException)
        {
            MessageBox.Show(this, ex.Message, "No se pudo registrar la devolución",
                MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        // Todo bien: DialogResult = true cierra la ventana y avisa a la principal para que recargue la lista.
        DialogResult = true;
    }
}
