// FORMULARIO DE PRÉSTAMO NUEVO (código): validaciones y guardado.
using System.IO;
using System.Net.Mail;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using PrestamosGC.Datos;

namespace PrestamosGC;

public partial class VentanaPrestamo : Window
{
    // ===== DATOS DE LA VENTANA =====

    // Constantes: valores fijos que se usan en varios sitios. Si cambian, se cambian solo aquí.
    private const string DominioCorreo = "@g.educaand.es";
    private const int MaxDiasPrestamo = 14;

    // Diccionario: a cada campo le asocia el TextBlock donde se escribe su error.
    // Así un único método (CampoCambiado) sirve para todos los campos.
    private readonly Dictionary<Control, TextBlock> _errores;

    // El préstamo que se ha creado. La ventana principal lo lee al cerrarse el formulario.
    // "private set": desde fuera solo se puede leer, no cambiar.
    public Prestamo? PrestamoCreado { get; private set; }

    // ===== CONSTRUCTOR =====
    public VentanaPrestamo()
    {
        InitializeComponent();

        // Rellenamos el diccionario campo → su mensaje de error.
        // Los tres RadioButton comparten el mismo error (errMotivo).
        _errores = new Dictionary<Control, TextBlock>
        {
            { txtNombre, errNombre },
            { txtApellidos, errApellidos },
            { cmbGrupo, errGrupo },
            { txtCorreo, errCorreo },
            { cmbPortatil, errPortatil },
            { rbProyecto, errMotivo },
            { rbPracticas, errMotivo },
            { rbOtro, errMotivo },
            { dpPrestamo, errFechaPrestamo },
            { dpDevolucion, errFechaDevolucion },
            { txtObservaciones, errObservaciones },
            { chkNormas, errNormas }
        };

        // El desplegable de portátiles solo muestra los que están libres.
        cmbPortatil.ItemsSource = App.Prestamos.PortatilesDisponibles();

        // DisplayDateStart: la primera fecha que se puede elegir (hoy; no hay fechas pasadas).
        dpPrestamo.DisplayDateStart = DateTime.Today;
        dpPrestamo.SelectedDate = DateTime.Today;
    }

    // ===== EVENTOS DE LOS CAMPOS =====

    // Al cambiar la fecha de préstamo, se recalculan las fechas de devolución permitidas:
    // desde el día siguiente hasta 14 días después.
    private void FechaPrestamo_SelectedDateChanged(object? sender, SelectionChangedEventArgs e)
    {
        OcultarError(dpPrestamo, errFechaPrestamo);

        // SelectedDate es DateTime? (puede ser null si el usuario borra la fecha).
        DateTime? prestamo = dpPrestamo.SelectedDate;
        if (prestamo == null)
        {
            // Sin fecha de préstamo, quitamos los límites de la devolución.
            dpDevolucion.DisplayDateStart = null;
            dpDevolucion.DisplayDateEnd = null;
            return;
        }

        // .Value saca la fecha del DateTime?. AddDays suma días.
        DateTime minimo = prestamo.Value.Date.AddDays(1);
        DateTime maximo = prestamo.Value.Date.AddDays(MaxDiasPrestamo);

        // Si la devolución elegida antes queda fuera del nuevo rango, la borramos.
        DateTime? devolucion = dpDevolucion.SelectedDate;
        if (devolucion != null && (devolucion.Value.Date < minimo || devolucion.Value.Date > maximo))
        {
            dpDevolucion.SelectedDate = null;
        }

        // Primero quitamos los límites antiguos y luego ponemos los nuevos.
        // Si no, WPF se queja cuando el nuevo inicio es mayor que el fin anterior.
        dpDevolucion.DisplayDateStart = null;
        dpDevolucion.DisplayDateEnd = null;
        dpDevolucion.DisplayDateStart = minimo;
        dpDevolucion.DisplayDateEnd = maximo;
    }

    // Cada vez que se escribe en Observaciones: actualiza el contador "n/200".
    private void Observaciones_TextChanged(object sender, TextChangedEventArgs e)
    {
        txtContador.Text = txtObservaciones.Text.Length + "/" + txtObservaciones.MaxLength;
        OcultarError(txtObservaciones, errObservaciones);
    }

    // Se ejecuta al elegir un motivo.
    private void Motivo_Checked(object sender, RoutedEventArgs e)
    {
        OcultarError(rbProyecto, errMotivo);

        // Si el motivo es "Otro", las observaciones pasan a ser obligatorias.
        bool esOtro = rbOtro.IsChecked == true;
        lblObservaciones.Text = esOtro ? "Observaciones (obligatorias)" : "Observaciones";

        // Si ya no es "Otro", quitamos el error de observaciones que hubiera.
        if (!esOtro)
        {
            OcultarError(txtObservaciones, errObservaciones);
        }
    }

    // Método COMPARTIDO por casi todos los campos: oculta el error del campo que se acaba de tocar.
    // "sender" es el control que lanzó el evento.
    private void CampoCambiado(object sender, RoutedEventArgs e)
    {
        // Al arrancar, algunos controles lanzan eventos antes de que exista el diccionario.
        if (_errores == null) return;

        // "is Control campo": comprueba que es un Control y lo guarda en "campo".
        // TryGetValue: busca el campo en el diccionario y saca su TextBlock de error.
        if (sender is Control campo && _errores.TryGetValue(campo, out TextBlock? error))
        {
            OcultarError(campo, error);
        }
    }

    // ===== MOSTRAR Y OCULTAR ERRORES =====

    // Muestra el mensaje de error y pone el borde del campo en rojo.
    private void MostrarError(Control campo, TextBlock error, string mensaje)
    {
        error.Text = mensaje;
        error.Visibility = Visibility.Visible;

        // Solo las cajas, desplegables y fechas tienen un borde que se pueda pintar de rojo.
        if (campo is TextBox or ComboBox or DatePicker)
        {
            // FindResource busca el color en los recursos (App.xaml).
            campo.BorderBrush = (Brush)FindResource("ColorError");
        }
    }

    // Oculta el mensaje y devuelve el borde a su color normal.
    private void OcultarError(Control campo, TextBlock error)
    {
        error.Text = "";
        error.Visibility = Visibility.Collapsed;
        // ClearValue quita el valor que pusimos a mano y vuelve al de por defecto.
        campo.ClearValue(Control.BorderBrushProperty);
    }

    // ===== BOTÓN REGISTRAR =====
    private void Registrar_Click(object sender, RoutedEventArgs e)
    {
        txtErrorGeneral.Visibility = Visibility.Collapsed;

        // Si algún campo está mal, Validar enseña los errores y aquí paramos.
        if (!Validar()) return;

        // Creamos el préstamo con los datos del formulario.
        // Trim() quita los espacios sobrantes al principio y al final.
        Prestamo prestamo = new Prestamo
        {
            Nombre = txtNombre.Text.Trim(),
            Apellidos = txtApellidos.Text.Trim(),
            // Los elementos del grupo son ComboBoxItem: el texto está en .Content
            Grupo = ((ComboBoxItem)cmbGrupo.SelectedItem!).Content?.ToString() ?? "",
            Correo = txtCorreo.Text.Trim(),
            // Los portátiles son texto (string) directamente.
            Portatil = (string)cmbPortatil.SelectedItem!,
            Motivo = MotivoSeleccionado() ?? "",
            IncluyeCargador = chkCargador.IsChecked == true,
            Observaciones = txtObservaciones.Text.Trim(),
            // El "!" indica que ya sabemos que no es null (Validar lo comprobó).
            FechaPrestamo = dpPrestamo.SelectedDate!.Value.Date,
            FechaDevolucionPrevista = dpDevolucion.SelectedDate!.Value.Date
        };

        // try/catch: si InsertarPrestamo falla, no se cae el programa: se enseña el error.
        try
        {
            App.Prestamos.InsertarPrestamo(prestamo);
        }
        catch (InvalidOperationException ex)
        {
            // Error de regla de negocio, por ejemplo "El portátil ya está prestado".
            MostrarErrorGeneral(ex.Message);
            return;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Error al guardar el archivo JSON (disco, permisos...).
            MostrarErrorGeneral("No se ha podido guardar el préstamo: " + ex.Message);
            return;
        }

        // Todo bien: guardamos el préstamo para la ventana principal.
        PrestamoCreado = prestamo;
        // DialogResult = true: cierra la ventana y devuelve true a ShowDialog.
        DialogResult = true;
    }

    // Muestra el error general (el que no pertenece a ningún campo).
    private void MostrarErrorGeneral(string mensaje)
    {
        txtErrorGeneral.Text = mensaje;
        txtErrorGeneral.Visibility = Visibility.Visible;
    }

    // Devuelve el motivo marcado o null si no hay ninguno.
    // El "?" del tipo (string?) significa que puede valer null.
    private string? MotivoSeleccionado()
    {
        if (rbProyecto.IsChecked == true) return "Proyecto";
        if (rbPracticas.IsChecked == true) return "Prácticas";
        if (rbOtro.IsChecked == true) return "Otro";
        return null;
    }

    // ===== VALIDACIÓN =====
    // Revisa todos los campos. Devuelve true si todo está bien.
    // Marca TODOS los errores a la vez y pone el cursor en el primer campo con error.
    private bool Validar()
    {
        // Aquí guardamos el primer campo con error.
        Control? primero = null;

        // Función local: la usamos dentro de Validar para no repetir código.
        // Muestra el error y, si es el primero, guarda el campo.
        // "??=" significa: si "primero" está vacío (null), guarda aquí el campo.
        void Error(Control campo, TextBlock error, string mensaje)
        {
            MostrarError(campo, error, mensaje);
            primero ??= campo;
        }

        // Nombre y apellidos: obligatorios (IsNullOrWhiteSpace: vacío o solo espacios).
        if (string.IsNullOrWhiteSpace(txtNombre.Text))
            Error(txtNombre, errNombre, "Campo obligatorio.");

        if (string.IsNullOrWhiteSpace(txtApellidos.Text))
            Error(txtApellidos, errApellidos, "Campo obligatorio.");

        // Grupo: tiene que haber algo elegido.
        if (cmbGrupo.SelectedItem == null)
            Error(cmbGrupo, errGrupo, "Elige un grupo.");

        // Correo: debe ser un correo válido, acabar en @g.educaand.es y tener algo antes de la @.
        string correo = txtCorreo.Text.Trim();
        bool correoValido =
            // TryCreate comprueba que el formato es de correo (algo@algo.algo).
            MailAddress.TryCreate(correo, out MailAddress? direccion) &&
            // Descarta cosas como "Juan <a@b.es>": la dirección tiene que ser igual al texto.
            string.Equals(direccion.Address, correo, StringComparison.OrdinalIgnoreCase) &&
            // Tiene que acabar en el dominio del centro (sin importar mayúsculas)...
            correo.EndsWith(DominioCorreo, StringComparison.OrdinalIgnoreCase) &&
            // ...y no puede ser solo el dominio: antes de la @ tiene que haber algo.
            correo.Length > DominioCorreo.Length;
        if (!correoValido)
            Error(txtCorreo, errCorreo, "Usa el correo del centro (" + DominioCorreo + ").");

        // Portátil: tiene que haber uno elegido.
        if (cmbPortatil.SelectedItem == null)
            Error(cmbPortatil, errPortatil, "Elige un portátil.");

        // Motivo: tiene que haber uno marcado. Como el error es de los tres botones,
        // pasamos el primero (rbProyecto) como campo al que dar el foco.
        string? motivo = MotivoSeleccionado();
        if (motivo == null)
            Error(rbProyecto, errMotivo, "Elige un motivo.");

        // Fecha de préstamo: no puede estar vacía ni ser anterior a hoy.
        DateTime? fechaPrestamo = dpPrestamo.SelectedDate;
        if (fechaPrestamo == null || fechaPrestamo.Value.Date < DateTime.Today)
            Error(dpPrestamo, errFechaPrestamo, "La fecha no puede ser anterior a hoy.");

        // Fecha de devolución: tiene que estar entre 1 y 14 días después del préstamo.
        DateTime? fechaDevolucion = dpDevolucion.SelectedDate;
        if (fechaDevolucion == null)
        {
            Error(dpDevolucion, errFechaDevolucion, "El préstamo dura entre 1 y " + MaxDiasPrestamo + " días.");
        }
        else if (fechaPrestamo != null)
        {
            // Restar dos fechas da un TimeSpan; .Days son los días de diferencia.
            int dias = (fechaDevolucion.Value.Date - fechaPrestamo.Value.Date).Days;
            if (dias < 1 || dias > MaxDiasPrestamo)
                Error(dpDevolucion, errFechaDevolucion, "El préstamo dura entre 1 y " + MaxDiasPrestamo + " días.");
        }

        // Observaciones: obligatorias solo si el motivo es "Otro".
        if (motivo == "Otro" && string.IsNullOrWhiteSpace(txtObservaciones.Text))
            Error(txtObservaciones, errObservaciones, "Explica el motivo del préstamo.");

        // Normas: tienen que estar aceptadas.
        if (chkNormas.IsChecked != true)
            Error(chkNormas, errNormas, "El alumno debe aceptar las normas.");

        // Si hubo algún error: ponemos el cursor en el primero y devolvemos false.
        if (primero != null)
        {
            primero.Focus();
            return false;
        }

        return true;
    }
}
