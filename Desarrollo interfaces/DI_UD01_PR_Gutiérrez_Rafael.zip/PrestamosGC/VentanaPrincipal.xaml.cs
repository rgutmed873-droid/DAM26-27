// VENTANA PRINCIPAL (código): carga la lista, aplica los filtros y abre las otras ventanas.
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using PrestamosGC.Datos;

namespace PrestamosGC;

// "partial": la otra mitad de esta clase la genera WPF a partir del XAML.
public partial class VentanaPrincipal : Window
{
    // Constructor: se ejecuta al abrir la ventana.
    public VentanaPrincipal()
    {
        // Crea los controles del XAML. Siempre va primero.
        InitializeComponent();
        // Rellena la lista por primera vez.
        CargarLista();
    }

    // Rellena la lista según el filtro elegido y actualiza la barra de estado.
    private void CargarLista()
    {
        // App.Prestamos es el gestor de datos, que ya viene dado.
        List<Prestamo> todos = App.Prestamos.ObtenerPrestamos();

        // Empezamos con todos y, si hay un filtro marcado, nos quedamos solo con los que cumplen.
        IEnumerable<Prestamo> visibles = todos;

        // Where (LINQ): deja solo los elementos que cumplen la condición.
        if (rbActivos.IsChecked == true)
            visibles = todos.Where(p => p.EstaActivo && !p.EstaVencido);
        else if (rbVencidos.IsChecked == true)
            visibles = todos.Where(p => p.EstaVencido);
        else if (rbDevueltos.IsChecked == true)
            visibles = todos.Where(p => p.EstaDevuelto);

        // ItemsSource: la lista de datos que muestra el ListBox.
        lstPrestamos.ItemsSource = visibles.ToList();

        // Count (LINQ): cuenta cuántos cumplen la condición. Se cuenta sobre "todos",
        // para que la barra de estado no cambie al cambiar el filtro.
        int enPrestamo = todos.Count(p => p.EstaActivo && !p.EstaVencido);
        int vencidos = todos.Count(p => p.EstaVencido);
        int disponibles = App.Prestamos.PortatilesDisponibles().Count;

        // Singular o plural según el número. Condición ? si_es_cierto : si_es_falso
        string textoVencidos = vencidos == 1 ? "vencido" : "vencidos";
        string textoDisponibles = disponibles == 1 ? "portátil disponible" : "portátiles disponibles";

        txtEstado.Text = enPrestamo + " en préstamo · " +
                         vencidos + " " + textoVencidos + " · " +
                         disponibles + " " + textoDisponibles +
                         " de " + App.Prestamos.TotalPortatiles;
    }

    // Se ejecuta al marcar cualquiera de los cuatro filtros.
    private void Filtro_Checked(object sender, RoutedEventArgs e)
    {
        // Al arrancar, "Todos" ya viene marcado y este evento salta mientras la ventana
        // aún se está creando (los demás controles todavía no existen).
        // Con este "if" nos salimos en ese caso para que no dé error.
        if (!IsInitialized) return;
        CargarLista();
    }

    // Se ejecuta al seleccionar una fila de la lista.
    private void Lista_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        // El botón "Ver detalle" solo se activa si hay algo seleccionado.
        btnDetalle.IsEnabled = lstPrestamos.SelectedItem != null;
    }

    // Botón "Nuevo préstamo": abre el formulario como ventana modal.
    private void Nuevo_Click(object sender, RoutedEventArgs e)
    {
        // Owner = this: la ventana nueva queda "dentro" de esta (se centra sobre ella).
        VentanaPrestamo ventana = new VentanaPrestamo { Owner = this };

        // ShowDialog: abre la ventana y espera a que se cierre (modal).
        // Devuelve true si se registró el préstamo. Si se canceló, salimos sin hacer nada.
        if (ventana.ShowDialog() != true || ventana.PrestamoCreado == null) return;

        // Ponemos el filtro en "Todos" para que el préstamo nuevo seguro aparezca en la lista.
        // Esto dispara Filtro_Checked, que ya recarga la lista.
        rbTodos.IsChecked = true;
        CargarLista();

        // Buscamos el préstamo nuevo en la lista por su Id para seleccionarlo.
        int idNuevo = ventana.PrestamoCreado.Id;
        Prestamo? nuevo = lstPrestamos.Items.Cast<Prestamo>().FirstOrDefault(p => p.Id == idNuevo);
        if (nuevo != null)
        {
            lstPrestamos.SelectedItem = nuevo;
            // ScrollIntoView: baja la lista hasta que se vea esa fila.
            lstPrestamos.ScrollIntoView(nuevo);
        }
    }

    // Botón "Ver detalle".
    private void Detalle_Click(object sender, RoutedEventArgs e)
    {
        AbrirDetalle();
    }

    // Doble clic en la lista: abre el detalle, pero solo si se hizo clic sobre una fila
    // (así un doble clic en el hueco vacío de la lista no hace nada).
    private void Lista_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        DependencyObject? origen = e.OriginalSource as DependencyObject;
        if (origen != null && ItemsControl.ContainerFromElement(lstPrestamos, origen) is ListBoxItem)
        {
            AbrirDetalle();
        }
    }

    // Abre la ventana de detalle del préstamo seleccionado (la usan el botón y el doble clic).
    private void AbrirDetalle()
    {
        // "is not Prestamo prestamo": si no hay nada seleccionado, salimos;
        // si lo hay, lo guardamos en la variable "prestamo".
        if (lstPrestamos.SelectedItem is not Prestamo prestamo) return;

        VentanaDetalle detalle = new VentanaDetalle(prestamo) { Owner = this };

        // La ventana de detalle devuelve true si se registró una devolución.
        // En ese caso recargamos la lista para ver el cambio.
        if (detalle.ShowDialog() == true)
        {
            CargarLista();
        }
    }

    // Se ejecuta justo antes de cerrar la ventana principal.
    // Si hay préstamos vencidos, pregunta si de verdad se quiere salir.
    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        int vencidos = App.Prestamos.ObtenerPrestamos().Count(p => p.EstaVencido);
        if (vencidos == 0) return;   // sin vencidos, se cierra sin preguntar

        string mensaje = vencidos == 1
            ? "Hay 1 préstamo vencido. ¿Quieres salir de todos modos?"
            : "Hay " + vencidos + " préstamos vencidos. ¿Quieres salir de todos modos?";

        // El último dato (MessageBoxResult.No) es el botón que queda marcado por defecto.
        MessageBoxResult respuesta = MessageBox.Show(
            this, mensaje, "Préstamos vencidos",
            MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);

        // e.Cancel = true cancela el cierre: la ventana se queda abierta.
        if (respuesta == MessageBoxResult.No)
        {
            e.Cancel = true;
        }
    }
}
